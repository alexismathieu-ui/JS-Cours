// TP10 - dashboard.js

(() => {
    const REFRESH_MS = 5000;
    const FETCH_TIMEOUT_MS = 7000;

    const state = {
        server: localStorage.getItem("tp10_server") || "http://13.38.137.68:8000/",
        players: [],
        selectedPlayer: null,
        refreshTimer: null,
        isRefreshing: false,
    };

    // ---------- DOM helpers ----------
    function el(tag, attrs = {}, children = []) {
        const node = document.createElement(tag);
        for (const [k, v] of Object.entries(attrs)) {
            if (k === "class") node.className = v;
            else if (k === "text") node.textContent = v;
            else if (k.startsWith("on") && typeof v === "function") node.addEventListener(k.slice(2), v);
            else node.setAttribute(k, v);
        }
        for (const child of children) node.append(child);
        return node;
    }

    function ensureUI() {
        const root =
            document.getElementById("dashboardRoot") ||
            el("div", { id: "dashboardRoot", class: "dashboard-root" });

        if (!root.isConnected) document.body.prepend(root);

        // Controls
        let controls = document.getElementById("controls");
        if (!controls) {
            controls = el("div", { id: "controls", class: "controls" });
            root.append(controls);
        }

        let serverInput = document.getElementById("serverInput");
        if (!serverInput) {
            const label = el("label", { for: "serverInput", text: "Serveur (IP:PORT) : " });
            serverInput = el("input", {
                id: "serverInput",
                type: "text",
                placeholder: "127.0.0.1:8000",
                value: state.server,
            });
            const btn = el("button", { id: "serverBtn", type: "button", text: "Connecter" });

            btn.addEventListener("click", () => {
                const raw = serverInput.value.trim();
                if (!raw) return setStatus("Adresse serveur vide.", "error");
                setServer(raw);
            });

            serverInput.addEventListener("keydown", (e) => {
                if (e.key === "Enter") document.getElementById("serverBtn")?.click();
            });

            controls.append(label, serverInput, btn);
        } else {
            serverInput.value = state.server;
        }

        let status = document.getElementById("status");
        if (!status) {
            status = el("div", { id: "status", class: "status" });
            controls.append(status);
        }

        // Main layout
        let main = document.getElementById("main");
        if (!main) {
            main = el("div", { id: "main", class: "main" });
            root.append(main);
        }

        // Players
        let playersPanel = document.getElementById("playersPanel");
        if (!playersPanel) {
            playersPanel = el("div", { id: "playersPanel", class: "panel" }, [
                el("h2", { text: "Joueurs" }),
            ]);
            main.append(playersPanel);
        }

        let playersSelect = document.getElementById("playersSelect");
        if (!playersSelect) {
            playersSelect = el("select", { id: "playersSelect" });
            playersSelect.addEventListener("change", async () => {
                const name = playersSelect.value || null;
                state.selectedPlayer = name;
                if (!name) {
                    renderStats(null);
                    return;
                }
                await refreshSelectedStats();
            });
            playersPanel.append(playersSelect);
        }

        // Stats
        let statsPanel = document.getElementById("statsPanel");
        if (!statsPanel) {
            statsPanel = el("div", { id: "statsPanel", class: "panel" }, [
                el("h2", { text: "Statistiques" }),
            ]);
            main.append(statsPanel);
        }

        let statsBox = document.getElementById("playerStats");
        if (!statsBox) {
            statsBox = el("div", { id: "playerStats", class: "stats-box" });
            statsPanel.append(statsBox);
        }

        // Ranking
        let rankingPanel = document.getElementById("rankingPanel");
        if (!rankingPanel) {
            rankingPanel = el("div", { id: "rankingPanel", class: "panel" }, [
                el("h2", { text: "Classement" }),
            ]);
            main.append(rankingPanel);
        }

        let rankingTable = document.getElementById("rankingTable");
        if (!rankingTable) {
            rankingTable = el("table", { id: "rankingTable", class: "ranking-table" });
            rankingPanel.append(rankingTable);
        }

        return { root };
    }

    function setStatus(message, kind = "info") {
        const status = document.getElementById("status");
        if (!status) return;
        status.textContent = message || "";
        status.dataset.kind = kind;
    }

    // ---------- Server / fetch ----------
    function normalizeServer(raw) {
        // Accept "IP:PORT" or full URL.
        let s = raw.trim();
        if (!s) return "";
        if (!/^https?:\/\//i.test(s)) s = `http://${s}`;
        s = s.replace(/\/+$/, "");
        return s;
    }

    function setServer(raw) {
        const normalized = normalizeServer(raw);
        if (!normalized) return;

        state.server = normalized.replace(/^https?:\/\//i, ""); // store as IP:PORT for display
        localStorage.setItem("tp10_server", state.server);

        const input = document.getElementById("serverInput");
        if (input) input.value = state.server;

        setStatus(`Serveur: ${state.server}`, "info");
        refreshAll(true).catch(() => {});
    }

    async function fetchJson(path, params = {}) {
        const base = normalizeServer(state.server);
        const url = new URL(base + path);

        for (const [k, v] of Object.entries(params)) {
            if (v !== undefined && v !== null) url.searchParams.set(k, String(v));
        }

        const controller = new AbortController();
        const t = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);

        try {
            const res = await fetch(url, { method: "GET", signal: controller.signal });
            if (!res.ok) {
                const text = await res.text().catch(() => "");
                throw new Error(`HTTP ${res.status} ${res.statusText}${text ? ` - ${text}` : ""}`);
            }
            return await res.json();
        } finally {
            clearTimeout(t);
        }
    }

    // ---------- API functions (required) ----------
    async function loadPlayers() {
        // /api/listPlayers
        const json = await fetchJson("/api/listPlayers");
        // Accept multiple shapes: ["a","b"] OR {players:[...]} OR {data:[...]}
        const players =
            Array.isArray(json) ? json : json?.players || json?.data || json?.result || [];
        if (!Array.isArray(players)) return [];
        return players.map(String);
    }

    async function loadPlayerStats(name) {
        // /api/stats?name=PLAYER_NAME
        if (!name) throw new Error("Nom joueur manquant");
        const json = await fetchJson("/api/stats", { name });
        // Stats can be direct object or nested
        return json?.stats || json?.data || json;
    }

    async function loadRanking() {
        // Build ranking from stats of all players (no dedicated endpoint provided).
        const players = state.players.slice();
        const statsList = await Promise.all(
            players.map(async (name) => {
                try {
                    const stats = await loadPlayerStats(name);
                    return { name, stats };
                } catch (e) {
                    return { name, stats: null, error: e };
                }
            })
        );

        const rows = statsList.map(({ name, stats }) => {
            const wins = num(stats?.wins ?? stats?.win ?? stats?.victories);
            const losses = num(stats?.losses ?? stats?.lose ?? stats?.defeats);
            const draws = num(stats?.draws ?? stats?.ties);
            const games = num(stats?.games ?? stats?.played ?? wins + losses + draws);
            const score = num(stats?.score ?? stats?.elo ?? stats?.rating ?? wins);

            const winRate = games > 0 ? (wins / games) * 100 : 0;

            return { name, score, wins, losses, draws, games, winRate, stats };
        });

        // Sort by score desc, then winrate desc, then games desc, then name asc
        rows.sort((a, b) => {
            if (b.score !== a.score) return b.score - a.score;
            if (b.winRate !== a.winRate) return b.winRate - a.winRate;
            if (b.games !== a.games) return b.games - a.games;
            return a.name.localeCompare(b.name);
        });

        return rows;
    }

    // ---------- Rendering ----------
    function renderPlayers(players) {
        const select = document.getElementById("playersSelect");
        if (!select) return;

        const prev = state.selectedPlayer;
        select.innerHTML = "";

        select.append(el("option", { value: "", text: "-- Choisir un joueur --" }));

        for (const name of players) {
            select.append(el("option", { value: name, text: name }));
        }

        // Restore selection if still present
        if (prev && players.includes(prev)) {
            select.value = prev;
        } else {
            state.selectedPlayer = select.value || null;
            renderStats(null);
        }
    }

    function renderStats(stats) {
        const box = document.getElementById("playerStats");
        if (!box) return;

        box.innerHTML = "";

        if (!stats) {
            box.append(el("div", { class: "muted", text: "Aucun joueur sélectionné." }));
            return;
        }

        const entries = Object.entries(stats);
        if (entries.length === 0) {
            box.append(el("div", { class: "muted", text: "Statistiques vides." }));
            return;
        }

        const list = el("dl", { class: "stats-dl" });
        for (const [k, v] of entries) {
            list.append(el("dt", { text: k }));
            list.append(el("dd", { text: typeof v === "object" ? JSON.stringify(v) : String(v) }));
        }
        box.append(list);
    }

    function renderRanking(rows) {
        const table = document.getElementById("rankingTable");
        if (!table) return;

        table.innerHTML = "";

        const thead = el("thead", {}, [
            el("tr", {}, [
                el("th", { text: "#" }),
                el("th", { text: "Joueur" }),
                el("th", { text: "Score" }),
                el("th", { text: "V" }),
                el("th", { text: "D" }),
                el("th", { text: "N" }),
                el("th", { text: "Parties" }),
                el("th", { text: "Winrate" }),
            ]),
        ]);

        const tbody = el("tbody");
        rows.forEach((r, idx) => {
            tbody.append(
                el("tr", {}, [
                    el("td", { text: String(idx + 1) }),
                    el("td", { text: r.name }),
                    el("td", { text: fmt(r.score) }),
                    el("td", { text: fmt(r.wins) }),
                    el("td", { text: fmt(r.losses) }),
                    el("td", { text: fmt(r.draws) }),
                    el("td", { text: fmt(r.games) }),
                    el("td", { text: `${r.winRate.toFixed(1)}%` }),
                ])
            );
        });

        table.append(thead, tbody);
    }

    // ---------- Refresh logic ----------
    async function refreshSelectedStats() {
        const name = state.selectedPlayer;
        if (!name) return;

        try {
            setStatus(`Chargement stats: ${name}...`, "info");
            const stats = await loadPlayerStats(name);
            renderStats(stats);
            setStatus(`OK (stats: ${name})`, "ok");
        } catch (e) {
            renderStats(null);
            setStatus(`Erreur stats (${name}): ${errMsg(e)}`, "error");
        }
    }

    async function refreshAll(force = false) {
        if (state.isRefreshing && !force) return;
        state.isRefreshing = true;

        try {
            setStatus("Chargement joueurs...", "info");
            const players = await loadPlayers();
            state.players = players;
            renderPlayers(players);

            setStatus("Chargement classement...", "info");
            const ranking = await loadRanking();
            renderRanking(ranking);

            // If a player is selected, refresh stats too
            if (state.selectedPlayer) await refreshSelectedStats();
            else setStatus("OK", "ok");
        } catch (e) {
            setStatus(`Erreur réseau/API: ${errMsg(e)}`, "error");
        } finally {
            state.isRefreshing = false;
        }
    }

    // ---------- Utils ----------
    function num(v) {
        const n = Number(v);
        return Number.isFinite(n) ? n : 0;
    }

    function fmt(v) {
        const n = Number(v);
        if (Number.isFinite(n)) return String(n);
        return v == null ? "0" : String(v);
    }

    function errMsg(e) {
        if (!e) return "Erreur inconnue";
        if (e.name === "AbortError") return "Timeout";
        return e.message || String(e);
    }

    // ---------- Refresh logic ----------
async function refreshSelectedStats() {
        const name = state.selectedPlayer;
        if (!name) return;

        try {
            setStatus(`Chargement stats: ${name}...`, "info");
            const stats = await loadPlayerStats(name);
            renderStats(stats);
            setStatus(`OK (stats: ${name})`, "ok");
        } catch (e) {
            renderStats(null);
            setStatus(`Erreur stats (${name}): ${errMsg(e)}`, "error");
        }
    }

    // AJOUT: refresh auto (classement + stats du joueur sélectionné)
    async function refreshAuto(force = false) {
        if (state.isRefreshing && !force) return;
        state.isRefreshing = true;

        try {
            // On recharge aussi la liste des joueurs pour que le classement reste correct si elle change
            const players = await loadPlayers();
            state.players = players;
            renderPlayers(players);

            setStatus("Chargement classement...", "info");
            const ranking = await loadRanking();
            renderRanking(ranking);

            if (state.selectedPlayer) await refreshSelectedStats();
            else setStatus("OK", "ok");
        } catch (e) {
            setStatus(`Erreur réseau/API: ${errMsg(e)}`, "error");
        } finally {
            state.isRefreshing = false;
        }
    }

    async function refreshAll(force = false) {
        // Optionnel: garde refreshAll pour le 1er chargement, et délègue au refreshAuto
        return refreshAuto(force);
    }


    // ---------- Boot ----------
    document.addEventListener("DOMContentLoaded", async () => {
        ensureUI();
        setStatus(`Serveur: ${state.server}`, "info");

        // First load
        await refreshAll(true);

        // Auto refresh
        if (state.refreshTimer) clearInterval(state.refreshTimer);
        state.refreshTimer = setInterval(() => {
            refreshAuto(false).catch(() => {});
        }, REFRESH_MS);
    });

    // Expose for debugging if needed
    window.TP10 = {
        loadPlayers,
        loadPlayerStats,
        loadRanking,
        refreshAuto,
    };
})();
